<!DOCTYPE html>
<html>
<head>
    <title>CRUD Main Page</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Student Management</h2>
    <a href="insert.php">Add New Student</a><br><br>
    <a href="view.php">View All Students</a>
</body>
</html>
